---@class __f__AnonymousType0_1__message_j__TPar_ : System.Object
---@field public message any
local m = {}

---@virtual
---@param value any
---@return boolean
function m:Equals(value) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

__f__AnonymousType0_1__message_j__TPar_ = m
return m
