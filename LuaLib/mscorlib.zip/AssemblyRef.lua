---@class AssemblyRef : System.Object
---@field public EcmaPublicKey string @static
---@field public FrameworkPublicKeyFull string @static
---@field public FrameworkPublicKeyFull2 string @static
---@field public MicrosoftPublicKey string @static
---@field public MicrosoftJScript string @static
---@field public MicrosoftVSDesigner string @static
---@field public SystemData string @static
---@field public SystemDesign string @static
---@field public SystemDrawing string @static
---@field public SystemWeb string @static
---@field public SystemWebExtensions string @static
---@field public SystemWindowsForms string @static
local m = {}

AssemblyRef = m
return m
