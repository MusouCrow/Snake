---@class System.IProgress_1_T_ : table
local m = {}

---@abstract
---@param value any
function m:Report(value) end

System.IProgress_1_T_ = m
return m
