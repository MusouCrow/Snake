---@class Mono.Security.X509.X520 : System.Object
local m = {}

Mono.Security.X509.X520 = m
return m
