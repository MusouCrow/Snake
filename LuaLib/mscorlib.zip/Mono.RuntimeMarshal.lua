---@class Mono.RuntimeMarshal : System.Object
local m = {}

Mono.RuntimeMarshal = m
return m
