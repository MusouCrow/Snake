---@class Mono.Security.X509.X509Stores.Names : System.Object
---@field public Personal string @static
---@field public OtherPeople string @static
---@field public IntermediateCA string @static
---@field public TrustedRoot string @static
---@field public Untrusted string @static
local m = {}

Mono.Security.X509.X509Stores.Names = m
return m
