---@class System.MissingMethodException : System.MissingMemberException
---@field public Message string
local m = {}

System.MissingMethodException = m
return m
