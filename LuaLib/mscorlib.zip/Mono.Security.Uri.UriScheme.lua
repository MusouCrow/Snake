---@class Mono.Security.Uri.UriScheme : System.ValueType
---@field public scheme string
---@field public delimiter string
---@field public defaultPort number
local m = {}

Mono.Security.Uri.UriScheme = m
return m
