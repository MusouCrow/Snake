---@class System.Guid.GuidResult : System.ValueType
local m = {}

System.Guid.GuidResult = m
return m
