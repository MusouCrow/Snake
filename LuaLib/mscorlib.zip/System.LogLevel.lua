---@class System.LogLevel : System.Enum
---@field public Trace System.LogLevel @static
---@field public Status System.LogLevel @static
---@field public Warning System.LogLevel @static
---@field public Error System.LogLevel @static
---@field public Panic System.LogLevel @static
---@field public value__ number
local m = {}

System.LogLevel = m
return m
