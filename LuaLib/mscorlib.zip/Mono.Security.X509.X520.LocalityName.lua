---@class Mono.Security.X509.X520.LocalityName : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.LocalityName = m
return m
