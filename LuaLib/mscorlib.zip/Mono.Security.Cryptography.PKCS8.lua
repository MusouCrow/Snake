---@class Mono.Security.Cryptography.PKCS8 : System.Object
local m = {}

---@static
---@param data string
---@return Mono.Security.Cryptography.PKCS8.KeyInfo
function m.GetType(data) end

Mono.Security.Cryptography.PKCS8 = m
return m
