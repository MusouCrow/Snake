---@class System.GC.EndNoGCRegionStatus : System.Enum
---@field public Succeeded System.GC.EndNoGCRegionStatus @static
---@field public NotInProgress System.GC.EndNoGCRegionStatus @static
---@field public GCInduced System.GC.EndNoGCRegionStatus @static
---@field public AllocationExceeded System.GC.EndNoGCRegionStatus @static
---@field public value__ number
local m = {}

System.GC.EndNoGCRegionStatus = m
return m
