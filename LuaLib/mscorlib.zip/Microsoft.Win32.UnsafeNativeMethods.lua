---@class Microsoft.Win32.UnsafeNativeMethods : System.Object
local m = {}

Microsoft.Win32.UnsafeNativeMethods = m
return m
