---@class System.ConsoleCancelEventArgs : System.EventArgs
---@field public Cancel boolean
---@field public SpecialKey System.ConsoleSpecialKey
local m = {}

System.ConsoleCancelEventArgs = m
return m
