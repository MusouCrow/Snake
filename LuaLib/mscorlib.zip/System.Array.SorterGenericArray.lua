---@class System.Array.SorterGenericArray : System.ValueType
local m = {}

System.Array.SorterGenericArray = m
return m
