---@class System.GCNotificationStatus : System.Enum
---@field public Succeeded System.GCNotificationStatus @static
---@field public Failed System.GCNotificationStatus @static
---@field public Canceled System.GCNotificationStatus @static
---@field public Timeout System.GCNotificationStatus @static
---@field public NotApplicable System.GCNotificationStatus @static
---@field public value__ number
local m = {}

System.GCNotificationStatus = m
return m
