---@class System.Enum.EnumResult : System.ValueType
local m = {}

System.Enum.EnumResult = m
return m
