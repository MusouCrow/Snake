---@class Mono.Security.X509.PKCS5 : System.Object
---@field public pbeWithMD2AndDESCBC string @static
---@field public pbeWithMD5AndDESCBC string @static
---@field public pbeWithMD2AndRC2CBC string @static
---@field public pbeWithMD5AndRC2CBC string @static
---@field public pbeWithSHA1AndDESCBC string @static
---@field public pbeWithSHA1AndRC2CBC string @static
local m = {}

Mono.Security.X509.PKCS5 = m
return m
