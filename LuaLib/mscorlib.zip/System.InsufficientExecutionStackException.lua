---@class System.InsufficientExecutionStackException : System.SystemException
local m = {}

System.InsufficientExecutionStackException = m
return m
