---@class Mono.RuntimeStructs.GPtrArray : System.ValueType
local m = {}

Mono.RuntimeStructs.GPtrArray = m
return m
