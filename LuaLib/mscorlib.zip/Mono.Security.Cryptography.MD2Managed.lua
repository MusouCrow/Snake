---@class Mono.Security.Cryptography.MD2Managed : Mono.Security.Cryptography.MD2
local m = {}

---@virtual
function m:Initialize() end

Mono.Security.Cryptography.MD2Managed = m
return m
