---@class System.StackOverflowException : System.SystemException
local m = {}

System.StackOverflowException = m
return m
