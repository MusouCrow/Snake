---@class System.DataMisalignedException : System.SystemException
local m = {}

System.DataMisalignedException = m
return m
