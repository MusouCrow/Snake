---@class System.IComparable_1_T_ : table
local m = {}

---@abstract
---@param other any
---@return number
function m:CompareTo(other) end

System.IComparable_1_T_ = m
return m
