---@class Mono.Globalization.Unicode.MSCompatUnicodeTable.__c : System.Object
---@field public <>9 Mono.Globalization.Unicode.MSCompatUnicodeTable.__c @static
---@field public <>9__17_0 fun(x:Mono.Globalization.Unicode.Level2Map, y:Mono.Globalization.Unicode.Level2Map): @static
local m = {}

Mono.Globalization.Unicode.MSCompatUnicodeTable.__c = m
return m
