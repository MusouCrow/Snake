---@class Mono.RuntimeGenericParamInfoHandle : System.ValueType
local m = {}

Mono.RuntimeGenericParamInfoHandle = m
return m
