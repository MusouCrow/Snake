---@class UnityEngine_LightTypeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_LightTypeWrap = m
return m
