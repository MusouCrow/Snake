---@class Game.GridUtility : System.Object
---@field public SIZE number @static
local m = {}

---@static
---@param x number
---@param y number
---@return UnityEngine.Vector2
function m.ToPosition(x, y) end

Game.GridUtility = m
return m
