---@class Game_GridPositionWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_GridPositionWrap = m
return m
