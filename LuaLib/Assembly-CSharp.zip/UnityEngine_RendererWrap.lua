---@class UnityEngine_RendererWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_RendererWrap = m
return m
