---@class DelegateFactory.UnityEngine_Application_LowMemoryCallback_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.UnityEngine_Application_LowMemoryCallback_Event = m
return m
