---@class Game_GridUtilityWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_GridUtilityWrap = m
return m
