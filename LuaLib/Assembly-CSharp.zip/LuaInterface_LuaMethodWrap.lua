---@class LuaInterface_LuaMethodWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_LuaMethodWrap = m
return m
