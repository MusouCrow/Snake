---@class LuaInterface
LuaInterface = {}