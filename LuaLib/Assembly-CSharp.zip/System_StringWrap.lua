---@class System_StringWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_StringWrap = m
return m
