---@class UnityEngine_TransformWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_TransformWrap = m
return m
