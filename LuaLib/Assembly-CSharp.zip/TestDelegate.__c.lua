---@class TestDelegate.__c : System.Object
---@field public <>9 TestDelegate.__c @static
---@field public <>9__17_0 fun(go:UnityEngine.GameObject) @static
---@field public <>9__19_0 fun(go:UnityEngine.GameObject) @static
local m = {}

TestDelegate.__c = m
return m
