---@class Game_GradientsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_GradientsWrap = m
return m
