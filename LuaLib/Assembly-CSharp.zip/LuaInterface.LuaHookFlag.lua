---@class LuaInterface.LuaHookFlag : System.Enum
---@field public LUA_HOOKCALL LuaInterface.LuaHookFlag @static
---@field public LUA_HOOKRET LuaInterface.LuaHookFlag @static
---@field public LUA_HOOKLINE LuaInterface.LuaHookFlag @static
---@field public LUA_HOOKCOUNT LuaInterface.LuaHookFlag @static
---@field public LUA_HOOKTAILRET LuaInterface.LuaHookFlag @static
---@field public value__ number
local m = {}

LuaInterface.LuaHookFlag = m
return m
