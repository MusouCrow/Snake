---@class System_Collections_ObjectModel_ReadOnlyCollectionWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_Collections_ObjectModel_ReadOnlyCollectionWrap = m
return m
