---@class LuaInterface.ObjectTranslator.DelayGC : System.Object
---@field public id number
---@field public obj UnityEngine.Object
---@field public time number
local m = {}

LuaInterface.ObjectTranslator.DelayGC = m
return m
