---@class LuaInterface.LuaDictEntry_2_K_V_ : System.ValueType
---@field public Key any
---@field public Value any
local m = {}

LuaInterface.LuaDictEntry_2_K_V_ = m
return m
