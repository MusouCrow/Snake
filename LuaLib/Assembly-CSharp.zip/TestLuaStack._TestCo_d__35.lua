---@class TestLuaStack._TestCo_d__35 : System.Object
---@field public action fun()
---@field public <>4__this TestLuaStack
local m = {}

TestLuaStack._TestCo_d__35 = m
return m
