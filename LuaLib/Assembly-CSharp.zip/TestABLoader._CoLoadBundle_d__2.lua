---@class TestABLoader._CoLoadBundle_d__2 : System.Object
---@field public name string
---@field public path string
---@field public <>4__this TestABLoader
local m = {}

TestABLoader._CoLoadBundle_d__2 = m
return m
