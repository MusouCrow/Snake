---@class DelegateFactory.System_Action_UnityEngine_AsyncOperation_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.AsyncOperation
function m:Call(param0) end

---@param param0 UnityEngine.AsyncOperation
function m:CallWithSelf(param0) end

DelegateFactory.System_Action_UnityEngine_AsyncOperation_Event = m
return m
