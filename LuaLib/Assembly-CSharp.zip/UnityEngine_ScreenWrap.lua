---@class UnityEngine_ScreenWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_ScreenWrap = m
return m
