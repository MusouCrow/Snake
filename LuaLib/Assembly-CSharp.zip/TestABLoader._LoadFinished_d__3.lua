---@class TestABLoader._LoadFinished_d__3 : System.Object
---@field public <>4__this TestABLoader
local m = {}

TestABLoader._LoadFinished_d__3 = m
return m
