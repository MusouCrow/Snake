---@class PassStruct : LuaClient
local m = {}

PassStruct = m
return m
