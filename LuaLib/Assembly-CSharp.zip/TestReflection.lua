---@class TestReflection : LuaClient
local m = {}

TestReflection = m
return m
