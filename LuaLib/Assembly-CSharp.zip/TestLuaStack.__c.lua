---@class TestLuaStack.__c : System.Object
---@field public <>9 TestLuaStack.__c @static
local m = {}

TestLuaStack.__c = m
return m
