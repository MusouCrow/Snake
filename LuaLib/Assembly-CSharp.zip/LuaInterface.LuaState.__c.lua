---@class LuaInterface.LuaState.__c : System.Object
---@field public <>9 LuaInterface.LuaState.__c @static
---@field public <>9__73_0 fun() @static
local m = {}

LuaInterface.LuaState.__c = m
return m
