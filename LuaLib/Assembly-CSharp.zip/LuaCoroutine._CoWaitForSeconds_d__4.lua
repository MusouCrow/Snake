---@class LuaCoroutine._CoWaitForSeconds_d__4 : System.Object
---@field public sec number
---@field public func LuaInterface.LuaFunction
local m = {}

LuaCoroutine._CoWaitForSeconds_d__4 = m
return m
