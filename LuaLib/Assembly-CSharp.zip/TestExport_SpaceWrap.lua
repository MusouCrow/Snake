---@class TestExport_SpaceWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

TestExport_SpaceWrap = m
return m
