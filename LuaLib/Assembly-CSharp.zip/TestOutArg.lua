---@class TestOutArg : UnityEngine.MonoBehaviour
local m = {}

TestOutArg = m
return m
