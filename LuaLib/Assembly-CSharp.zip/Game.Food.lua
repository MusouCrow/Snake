---@class Game.Food : UnityEngine.MonoBehaviour
---@field public gridPosition Game.GridPosition
local m = {}

Game.Food = m
return m
