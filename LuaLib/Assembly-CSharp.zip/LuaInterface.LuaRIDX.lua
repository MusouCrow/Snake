---@class LuaInterface.LuaRIDX : System.Object
---@field public LUA_RIDX_MAINTHREAD number
---@field public LUA_RIDX_GLOBALS number
---@field public LUA_RIDX_PRELOAD number
---@field public LUA_RIDX_LOADED number
local m = {}

LuaInterface.LuaRIDX = m
return m
