---@class TestProtolWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

TestProtolWrap = m
return m
