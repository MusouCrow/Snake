---@class TestExport.__c : System.Object
---@field public <>9 TestExport.__c @static
---@field public <>9__48_0 fun() @static
---@field public <>9__49_0 fun() @static
---@field public <>9__50_0 fun() @static
---@field public <>9__51_0 fun() @static
local m = {}

TestExport.__c = m
return m
