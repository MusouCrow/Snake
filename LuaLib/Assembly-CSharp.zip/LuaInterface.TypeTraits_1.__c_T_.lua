---@class LuaInterface.TypeTraits_1.__c_T_ : System.Object
---@field public <>9 LuaInterface.TypeTraits_1.__c_T_ @static
---@field public <>9__9_0 fun() @static
local m = {}

LuaInterface.TypeTraits_1.__c_T_ = m
return m
