---@class LuaInterface.LuaIndexes : System.Object
---@field public LUA_REGISTRYINDEX number @static
---@field public LUA_ENVIRONINDEX number @static
---@field public LUA_GLOBALSINDEX number @static
local m = {}

LuaInterface.LuaIndexes = m
return m
