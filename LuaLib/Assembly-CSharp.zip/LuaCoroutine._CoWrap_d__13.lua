---@class LuaCoroutine._CoWrap_d__13 : System.Object
---@field public func LuaInterface.LuaFunction
local m = {}

LuaCoroutine._CoWrap_d__13 = m
return m
