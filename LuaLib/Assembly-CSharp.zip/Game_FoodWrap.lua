---@class Game_FoodWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_FoodWrap = m
return m
