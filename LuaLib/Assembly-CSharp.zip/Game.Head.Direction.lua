---@class Game.Head.Direction : System.Enum
---@field public up Game.Head.Direction @static
---@field public down Game.Head.Direction @static
---@field public right Game.Head.Direction @static
---@field public left Game.Head.Direction @static
---@field public value__ number
local m = {}

Game.Head.Direction = m
return m
