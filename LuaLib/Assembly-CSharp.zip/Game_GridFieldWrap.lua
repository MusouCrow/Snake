---@class Game_GridFieldWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_GridFieldWrap = m
return m
