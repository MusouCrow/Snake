---@class TestCoroutine : UnityEngine.MonoBehaviour
---@field public luaFile UnityEngine.TextAsset
local m = {}

TestCoroutine = m
return m
