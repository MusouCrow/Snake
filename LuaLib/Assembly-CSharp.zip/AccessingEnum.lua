---@class AccessingEnum : UnityEngine.MonoBehaviour
local m = {}

AccessingEnum = m
return m
