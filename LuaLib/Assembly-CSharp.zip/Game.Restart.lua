---@class Game.Restart : UnityEngine.MonoBehaviour
local m = {}

Game.Restart = m
return m
