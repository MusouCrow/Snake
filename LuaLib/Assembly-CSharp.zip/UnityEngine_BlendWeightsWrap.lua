---@class UnityEngine_BlendWeightsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_BlendWeightsWrap = m
return m
