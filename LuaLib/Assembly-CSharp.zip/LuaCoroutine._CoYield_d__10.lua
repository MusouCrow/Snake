---@class LuaCoroutine._CoYield_d__10 : System.Object
---@field public o any
---@field public func LuaInterface.LuaFunction
local m = {}

LuaCoroutine._CoYield_d__10 = m
return m
