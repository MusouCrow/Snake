---@class Game.GridField : UnityEngine.MonoBehaviour
---@field public ASPECT_W number @static
---@field public ASPECT_H number @static
local m = {}

Game.GridField = m
return m
