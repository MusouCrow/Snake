---@class DelegateFactory.__c : System.Object
---@field public <>9 DelegateFactory.__c @static
---@field public <>9__10_0 fun() @static
---@field public <>9__14_0 fun() @static
---@field public <>9__18_0 fun(obj:number): @static
---@field public <>9__22_0 fun(obj:number) @static
---@field public <>9__26_0 fun(x:number, y:number): @static
---@field public <>9__30_0 fun(arg:number): @static
---@field public <>9__34_0 fun(cam:UnityEngine.Camera) @static
---@field public <>9__38_0 fun(advertisingId:string, trackingEnabled:boolean, errorMsg:string) @static
---@field public <>9__42_0 fun() @static
---@field public <>9__46_0 fun(condition:string, stackTrace:string, type:UnityEngine.LogType) @static
---@field public <>9__50_0 fun(obj:boolean) @static
---@field public <>9__54_0 fun(): @static
---@field public <>9__58_0 fun(data:number[]) @static
---@field public <>9__62_0 fun(position:number) @static
---@field public <>9__66_0 fun(obj:UnityEngine.AsyncOperation) @static
local m = {}

DelegateFactory.__c = m
return m
