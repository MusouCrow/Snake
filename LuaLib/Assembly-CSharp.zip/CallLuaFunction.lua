---@class CallLuaFunction : UnityEngine.MonoBehaviour
local m = {}

CallLuaFunction = m
return m
