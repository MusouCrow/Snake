---@class LuaInterface.LuaMask : System.Enum
---@field public LUA_MASKCALL LuaInterface.LuaMask @static
---@field public LUA_MASKRET LuaInterface.LuaMask @static
---@field public LUA_MASKLINE LuaInterface.LuaMask @static
---@field public LUA_MASKCOUNT LuaInterface.LuaMask @static
---@field public value__ number
local m = {}

LuaInterface.LuaMask = m
return m
