---@class LuaInterface.LuaDictTable_2.Enumerator_K_V_ : System.Object
---@field public Current System.ValueType
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Reset() end

---@virtual
function m:Dispose() end

LuaInterface.LuaDictTable_2.Enumerator_K_V_ = m
return m
