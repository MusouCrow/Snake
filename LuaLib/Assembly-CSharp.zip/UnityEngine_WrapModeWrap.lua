---@class UnityEngine_WrapModeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_WrapModeWrap = m
return m
