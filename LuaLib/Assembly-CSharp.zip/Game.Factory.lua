---@class Game.Factory : UnityEngine.MonoBehaviour
---@field public FoodCount number @static
local m = {}

Game.Factory = m
return m
