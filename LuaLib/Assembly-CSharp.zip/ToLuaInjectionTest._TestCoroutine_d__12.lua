---@class ToLuaInjectionTest._TestCoroutine_d__12 : System.Object
---@field public delay number
---@field public <>4__this ToLuaInjectionTest
local m = {}

ToLuaInjectionTest._TestCoroutine_d__12 = m
return m
