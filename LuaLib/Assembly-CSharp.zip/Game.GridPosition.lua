---@class Game.GridPosition : UnityEngine.MonoBehaviour
---@field public X number
---@field public Y number
---@field public Position UnityEngine.Vector2Int
local m = {}

Game.GridPosition = m
return m
