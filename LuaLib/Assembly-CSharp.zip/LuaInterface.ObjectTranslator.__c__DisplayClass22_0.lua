---@class LuaInterface.ObjectTranslator.__c__DisplayClass22_0 : System.Object
---@field public id number
local m = {}

LuaInterface.ObjectTranslator.__c__DisplayClass22_0 = m
return m
