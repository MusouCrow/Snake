---@class Game_FactoryWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_FactoryWrap = m
return m
