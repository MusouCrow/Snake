---@class Game.Gradients : UnityEngine.MonoBehaviour
local m = {}

Game.Gradients = m
return m
