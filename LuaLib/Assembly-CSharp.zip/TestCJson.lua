---@class TestCJson : LuaClient
local m = {}

TestCJson = m
return m
