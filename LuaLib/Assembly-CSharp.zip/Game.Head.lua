---@class Game.Head : UnityEngine.MonoBehaviour
---@field public TAIL Game.Body @static
local m = {}

function m:Reset() end

Game.Head = m
return m
