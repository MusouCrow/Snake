---@class Game_SystemWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_SystemWrap = m
return m
