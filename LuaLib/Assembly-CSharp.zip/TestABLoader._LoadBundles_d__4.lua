---@class TestABLoader._LoadBundles_d__4 : System.Object
---@field public <>4__this TestABLoader
local m = {}

TestABLoader._LoadBundles_d__4 = m
return m
