---@class TestEventListener.__c : System.Object
---@field public <>9 TestEventListener.__c @static
---@field public <>9__10_0 fun(go:UnityEngine.GameObject) @static
---@field public <>9__10_1 fun(go:UnityEngine.GameObject) @static
local m = {}

TestEventListener.__c = m
return m
