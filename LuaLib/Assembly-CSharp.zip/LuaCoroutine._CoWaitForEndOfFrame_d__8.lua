---@class LuaCoroutine._CoWaitForEndOfFrame_d__8 : System.Object
---@field public func LuaInterface.LuaFunction
local m = {}

LuaCoroutine._CoWaitForEndOfFrame_d__8 = m
return m
