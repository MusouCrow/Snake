---@class Game_HeadWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

Game_HeadWrap = m
return m
