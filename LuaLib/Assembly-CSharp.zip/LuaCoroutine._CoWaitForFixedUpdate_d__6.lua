---@class LuaCoroutine._CoWaitForFixedUpdate_d__6 : System.Object
---@field public func LuaInterface.LuaFunction
local m = {}

LuaCoroutine._CoWaitForFixedUpdate_d__6 = m
return m
