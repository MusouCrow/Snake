---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PhysicsSkinnedClothBeginUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PhysicsSkinnedClothBeginUpdate = m
return m
