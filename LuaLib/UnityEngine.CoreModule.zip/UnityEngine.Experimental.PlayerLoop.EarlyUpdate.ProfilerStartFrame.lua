---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ProfilerStartFrame : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ProfilerStartFrame = m
return m
