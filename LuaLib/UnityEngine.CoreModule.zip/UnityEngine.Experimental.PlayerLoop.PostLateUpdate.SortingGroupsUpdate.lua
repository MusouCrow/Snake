---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.SortingGroupsUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.SortingGroupsUpdate = m
return m
