---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.DirectorRenderImage : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.DirectorRenderImage = m
return m
