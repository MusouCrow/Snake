---@class UnityEngine.Rendering.ReflectionProbeBlendInfo : System.ValueType
---@field public probe UnityEngine.ReflectionProbe
---@field public weight number
local m = {}

UnityEngine.Rendering.ReflectionProbeBlendInfo = m
return m
