---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.DirectorFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.DirectorFixedUpdate = m
return m
