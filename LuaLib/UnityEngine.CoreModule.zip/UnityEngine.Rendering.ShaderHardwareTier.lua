---@class UnityEngine.Rendering.ShaderHardwareTier : System.Enum
---@field public Tier1 UnityEngine.Rendering.ShaderHardwareTier @static
---@field public Tier2 UnityEngine.Rendering.ShaderHardwareTier @static
---@field public Tier3 UnityEngine.Rendering.ShaderHardwareTier @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ShaderHardwareTier = m
return m
