---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.LegacyAnimationUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.LegacyAnimationUpdate = m
return m
