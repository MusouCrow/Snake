---@class UnityEngine.Experimental.PlayerLoop.Initialization.AsyncUploadTimeSlicedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Initialization.AsyncUploadTimeSlicedUpdate = m
return m
