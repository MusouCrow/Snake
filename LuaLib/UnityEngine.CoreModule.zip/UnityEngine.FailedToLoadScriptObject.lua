---@class UnityEngine.FailedToLoadScriptObject : UnityEngine.Object
local m = {}

UnityEngine.FailedToLoadScriptObject = m
return m
