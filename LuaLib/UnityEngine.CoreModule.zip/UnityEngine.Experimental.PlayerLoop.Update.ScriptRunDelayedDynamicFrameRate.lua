---@class UnityEngine.Experimental.PlayerLoop.Update.ScriptRunDelayedDynamicFrameRate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Update.ScriptRunDelayedDynamicFrameRate = m
return m
