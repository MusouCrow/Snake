---@class UnityEngine.LightProbeGroup : UnityEngine.Behaviour
---@field public probePositions UnityEngine.Vector3[]
---@field public dering boolean
local m = {}

UnityEngine.LightProbeGroup = m
return m
