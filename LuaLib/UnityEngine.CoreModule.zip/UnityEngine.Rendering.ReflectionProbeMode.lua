---@class UnityEngine.Rendering.ReflectionProbeMode : System.Enum
---@field public Baked UnityEngine.Rendering.ReflectionProbeMode @static
---@field public Realtime UnityEngine.Rendering.ReflectionProbeMode @static
---@field public Custom UnityEngine.Rendering.ReflectionProbeMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionProbeMode = m
return m
