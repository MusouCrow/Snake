---@class UnityEngine.ExcludeFromPresetAttribute : System.Attribute
local m = {}

UnityEngine.ExcludeFromPresetAttribute = m
return m
