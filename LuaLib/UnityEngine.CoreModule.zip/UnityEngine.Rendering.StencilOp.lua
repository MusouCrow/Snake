---@class UnityEngine.Rendering.StencilOp : System.Enum
---@field public Keep UnityEngine.Rendering.StencilOp @static
---@field public Zero UnityEngine.Rendering.StencilOp @static
---@field public Replace UnityEngine.Rendering.StencilOp @static
---@field public IncrementSaturate UnityEngine.Rendering.StencilOp @static
---@field public DecrementSaturate UnityEngine.Rendering.StencilOp @static
---@field public Invert UnityEngine.Rendering.StencilOp @static
---@field public IncrementWrap UnityEngine.Rendering.StencilOp @static
---@field public DecrementWrap UnityEngine.Rendering.StencilOp @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.StencilOp = m
return m
