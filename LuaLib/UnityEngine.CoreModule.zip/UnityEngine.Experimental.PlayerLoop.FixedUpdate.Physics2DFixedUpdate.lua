---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.Physics2DFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.Physics2DFixedUpdate = m
return m
