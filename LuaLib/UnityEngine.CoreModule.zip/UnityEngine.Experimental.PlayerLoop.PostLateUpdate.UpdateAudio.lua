---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateAudio : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateAudio = m
return m
