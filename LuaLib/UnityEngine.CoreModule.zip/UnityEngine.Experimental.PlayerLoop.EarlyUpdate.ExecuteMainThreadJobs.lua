---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ExecuteMainThreadJobs : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ExecuteMainThreadJobs = m
return m
