---@class UnityEngine.FilterMode : System.Enum
---@field public Point UnityEngine.FilterMode @static
---@field public Bilinear UnityEngine.FilterMode @static
---@field public Trilinear UnityEngine.FilterMode @static
---@field public value__ number
local m = {}

UnityEngine.FilterMode = m
return m
