---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateAllUnityWebStreams : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateAllUnityWebStreams = m
return m
