---@class UnityEngine.Experimental.PlayerLoop.Update.ScriptRunDelayedTasks : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Update.ScriptRunDelayedTasks = m
return m
