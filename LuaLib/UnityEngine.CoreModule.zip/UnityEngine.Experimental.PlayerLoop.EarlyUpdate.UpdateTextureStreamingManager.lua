---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateTextureStreamingManager : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateTextureStreamingManager = m
return m
