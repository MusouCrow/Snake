---@class UnityEngine.Experimental.PlayerLoop.Initialization.SynchronizeInputs : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Initialization.SynchronizeInputs = m
return m
