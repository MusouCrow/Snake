---@class UnityEngine.Experimental.LowLevel.PlayerLoopSystem : System.ValueType
---@field public type System.Type
---@field public subSystemList UnityEngine.Experimental.LowLevel.PlayerLoopSystem[]
---@field public updateDelegate fun()
---@field public updateFunction System.IntPtr
---@field public loopConditionFunction System.IntPtr
local m = {}

UnityEngine.Experimental.LowLevel.PlayerLoopSystem = m
return m
