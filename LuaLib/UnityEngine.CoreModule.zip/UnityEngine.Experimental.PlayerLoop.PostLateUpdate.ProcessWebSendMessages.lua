---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ProcessWebSendMessages : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ProcessWebSendMessages = m
return m
