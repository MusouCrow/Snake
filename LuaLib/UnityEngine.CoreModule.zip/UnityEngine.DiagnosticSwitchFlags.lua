---@class UnityEngine.DiagnosticSwitchFlags : System.Enum
---@field public None UnityEngine.DiagnosticSwitchFlags @static
---@field public CanChangeAfterEngineStart UnityEngine.DiagnosticSwitchFlags @static
---@field public value__ number
local m = {}

UnityEngine.DiagnosticSwitchFlags = m
return m
