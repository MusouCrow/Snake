---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.AudioFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.AudioFixedUpdate = m
return m
