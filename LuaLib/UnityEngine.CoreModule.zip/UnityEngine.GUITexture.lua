---@class UnityEngine.GUITexture : UnityEngine.GUIElement
---@field public color UnityEngine.Color
---@field public texture UnityEngine.Texture
---@field public pixelInset UnityEngine.Rect
---@field public border UnityEngine.RectOffset
local m = {}

UnityEngine.GUITexture = m
return m
