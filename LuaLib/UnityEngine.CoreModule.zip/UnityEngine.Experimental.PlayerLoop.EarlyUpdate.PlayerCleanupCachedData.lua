---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PlayerCleanupCachedData : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PlayerCleanupCachedData = m
return m
