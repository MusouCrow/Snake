---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdatePreloading : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdatePreloading = m
return m
