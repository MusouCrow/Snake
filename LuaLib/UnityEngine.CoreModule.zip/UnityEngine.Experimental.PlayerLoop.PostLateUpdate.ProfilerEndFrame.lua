---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ProfilerEndFrame : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ProfilerEndFrame = m
return m
