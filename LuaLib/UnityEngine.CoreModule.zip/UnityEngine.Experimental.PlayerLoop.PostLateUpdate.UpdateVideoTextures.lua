---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateVideoTextures : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateVideoTextures = m
return m
