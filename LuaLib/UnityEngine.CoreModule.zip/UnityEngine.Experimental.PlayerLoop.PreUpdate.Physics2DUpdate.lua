---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.Physics2DUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.Physics2DUpdate = m
return m
