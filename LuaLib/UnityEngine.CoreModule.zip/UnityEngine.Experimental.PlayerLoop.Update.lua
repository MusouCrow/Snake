---@class UnityEngine.Experimental.PlayerLoop.Update : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Update = m
return m
