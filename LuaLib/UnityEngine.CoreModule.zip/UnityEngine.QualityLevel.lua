---@class UnityEngine.QualityLevel : System.Enum
---@field public Fastest UnityEngine.QualityLevel @static
---@field public Fast UnityEngine.QualityLevel @static
---@field public Simple UnityEngine.QualityLevel @static
---@field public Good UnityEngine.QualityLevel @static
---@field public Beautiful UnityEngine.QualityLevel @static
---@field public Fantastic UnityEngine.QualityLevel @static
---@field public value__ number
local m = {}

UnityEngine.QualityLevel = m
return m
