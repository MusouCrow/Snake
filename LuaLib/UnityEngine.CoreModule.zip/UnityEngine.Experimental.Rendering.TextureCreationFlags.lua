---@class UnityEngine.Experimental.Rendering.TextureCreationFlags : System.Enum
---@field public None UnityEngine.Experimental.Rendering.TextureCreationFlags @static
---@field public MipChain UnityEngine.Experimental.Rendering.TextureCreationFlags @static
---@field public Crunch UnityEngine.Experimental.Rendering.TextureCreationFlags @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Rendering.TextureCreationFlags = m
return m
