---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate = m
return m
