---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.IMGUISendQueuedEvents : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.IMGUISendQueuedEvents = m
return m
