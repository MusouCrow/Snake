---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ScriptRunDelayedStartupFrame : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ScriptRunDelayedStartupFrame = m
return m
