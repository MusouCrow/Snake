---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate = m
return m
