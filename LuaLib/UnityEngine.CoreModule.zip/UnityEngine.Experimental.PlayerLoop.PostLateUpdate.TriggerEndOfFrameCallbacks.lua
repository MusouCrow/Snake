---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.TriggerEndOfFrameCallbacks : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.TriggerEndOfFrameCallbacks = m
return m
