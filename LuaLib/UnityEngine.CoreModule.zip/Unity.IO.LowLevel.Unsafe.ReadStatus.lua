---@class Unity.IO.LowLevel.Unsafe.ReadStatus : System.Enum
---@field public Complete Unity.IO.LowLevel.Unsafe.ReadStatus @static
---@field public InProgress Unity.IO.LowLevel.Unsafe.ReadStatus @static
---@field public Failed Unity.IO.LowLevel.Unsafe.ReadStatus @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.ReadStatus = m
return m
