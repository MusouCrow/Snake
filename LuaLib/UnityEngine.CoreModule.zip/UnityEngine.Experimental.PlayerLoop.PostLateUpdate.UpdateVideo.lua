---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateVideo : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateVideo = m
return m
