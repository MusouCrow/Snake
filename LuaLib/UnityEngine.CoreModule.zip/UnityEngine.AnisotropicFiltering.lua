---@class UnityEngine.AnisotropicFiltering : System.Enum
---@field public Disable UnityEngine.AnisotropicFiltering @static
---@field public Enable UnityEngine.AnisotropicFiltering @static
---@field public ForceEnable UnityEngine.AnisotropicFiltering @static
---@field public value__ number
local m = {}

UnityEngine.AnisotropicFiltering = m
return m
