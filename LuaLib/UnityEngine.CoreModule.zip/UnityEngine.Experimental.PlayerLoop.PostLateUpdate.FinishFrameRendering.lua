---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.FinishFrameRendering : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.FinishFrameRendering = m
return m
