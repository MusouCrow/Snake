---@class UnityEngine.BeforeRenderHelper.OrderBlock : System.ValueType
local m = {}

UnityEngine.BeforeRenderHelper.OrderBlock = m
return m
