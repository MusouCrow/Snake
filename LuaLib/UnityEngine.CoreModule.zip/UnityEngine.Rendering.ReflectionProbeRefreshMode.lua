---@class UnityEngine.Rendering.ReflectionProbeRefreshMode : System.Enum
---@field public OnAwake UnityEngine.Rendering.ReflectionProbeRefreshMode @static
---@field public EveryFrame UnityEngine.Rendering.ReflectionProbeRefreshMode @static
---@field public ViaScripting UnityEngine.Rendering.ReflectionProbeRefreshMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionProbeRefreshMode = m
return m
