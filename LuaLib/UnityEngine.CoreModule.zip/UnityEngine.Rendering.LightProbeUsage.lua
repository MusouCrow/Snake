---@class UnityEngine.Rendering.LightProbeUsage : System.Enum
---@field public Off UnityEngine.Rendering.LightProbeUsage @static
---@field public BlendProbes UnityEngine.Rendering.LightProbeUsage @static
---@field public UseProxyVolume UnityEngine.Rendering.LightProbeUsage @static
---@field public CustomProvided UnityEngine.Rendering.LightProbeUsage @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.LightProbeUsage = m
return m
