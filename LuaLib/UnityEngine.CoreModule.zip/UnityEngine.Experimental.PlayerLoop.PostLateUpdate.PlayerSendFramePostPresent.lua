---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerSendFramePostPresent : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerSendFramePostPresent = m
return m
