---@class UnityEngine.Rendering.ReflectionProbeClearFlags : System.Enum
---@field public Skybox UnityEngine.Rendering.ReflectionProbeClearFlags @static
---@field public SolidColor UnityEngine.Rendering.ReflectionProbeClearFlags @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionProbeClearFlags = m
return m
