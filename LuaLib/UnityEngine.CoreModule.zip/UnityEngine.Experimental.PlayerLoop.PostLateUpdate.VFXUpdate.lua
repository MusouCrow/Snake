---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.VFXUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.VFXUpdate = m
return m
