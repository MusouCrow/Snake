---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateResolution : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateResolution = m
return m
