---@class UnityEngine.ContextMenu : System.Attribute
---@field public menuItem string
---@field public validate boolean
---@field public priority number
local m = {}

UnityEngine.ContextMenu = m
return m
