---@class JetBrains.Annotations.PathReferenceAttribute : System.Attribute
---@field public BasePath string
local m = {}

JetBrains.Annotations.PathReferenceAttribute = m
return m
