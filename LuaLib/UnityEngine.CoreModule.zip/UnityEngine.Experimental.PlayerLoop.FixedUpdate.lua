---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate = m
return m
