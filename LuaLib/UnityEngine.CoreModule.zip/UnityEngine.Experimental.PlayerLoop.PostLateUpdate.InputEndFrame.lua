---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.InputEndFrame : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.InputEndFrame = m
return m
