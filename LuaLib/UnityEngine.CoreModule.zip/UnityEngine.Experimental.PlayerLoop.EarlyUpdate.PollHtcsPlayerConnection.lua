---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PollHtcsPlayerConnection : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PollHtcsPlayerConnection = m
return m
