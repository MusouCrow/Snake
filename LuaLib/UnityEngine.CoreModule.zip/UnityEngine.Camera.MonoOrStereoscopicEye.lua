---@class UnityEngine.Camera.MonoOrStereoscopicEye : System.Enum
---@field public Left UnityEngine.Camera.MonoOrStereoscopicEye @static
---@field public Right UnityEngine.Camera.MonoOrStereoscopicEye @static
---@field public Mono UnityEngine.Camera.MonoOrStereoscopicEye @static
---@field public value__ number
local m = {}

UnityEngine.Camera.MonoOrStereoscopicEye = m
return m
