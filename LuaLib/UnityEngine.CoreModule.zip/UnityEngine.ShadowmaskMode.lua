---@class UnityEngine.ShadowmaskMode : System.Enum
---@field public Shadowmask UnityEngine.ShadowmaskMode @static
---@field public DistanceShadowmask UnityEngine.ShadowmaskMode @static
---@field public value__ number
local m = {}

UnityEngine.ShadowmaskMode = m
return m
