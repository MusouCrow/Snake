---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ShaderHandleErrors : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ShaderHandleErrors = m
return m
