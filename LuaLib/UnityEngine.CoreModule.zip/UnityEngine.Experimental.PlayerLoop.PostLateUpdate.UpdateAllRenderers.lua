---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateAllRenderers : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateAllRenderers = m
return m
