---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ClearLines : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ClearLines = m
return m
