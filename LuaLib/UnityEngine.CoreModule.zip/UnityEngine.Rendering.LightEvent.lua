---@class UnityEngine.Rendering.LightEvent : System.Enum
---@field public BeforeShadowMap UnityEngine.Rendering.LightEvent @static
---@field public AfterShadowMap UnityEngine.Rendering.LightEvent @static
---@field public BeforeScreenspaceMask UnityEngine.Rendering.LightEvent @static
---@field public AfterScreenspaceMask UnityEngine.Rendering.LightEvent @static
---@field public BeforeShadowMapPass UnityEngine.Rendering.LightEvent @static
---@field public AfterShadowMapPass UnityEngine.Rendering.LightEvent @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.LightEvent = m
return m
