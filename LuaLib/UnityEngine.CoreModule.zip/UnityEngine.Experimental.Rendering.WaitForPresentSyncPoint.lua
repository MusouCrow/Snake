---@class UnityEngine.Experimental.Rendering.WaitForPresentSyncPoint : System.Enum
---@field public BeginFrame UnityEngine.Experimental.Rendering.WaitForPresentSyncPoint @static
---@field public EndFrame UnityEngine.Experimental.Rendering.WaitForPresentSyncPoint @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Rendering.WaitForPresentSyncPoint = m
return m
