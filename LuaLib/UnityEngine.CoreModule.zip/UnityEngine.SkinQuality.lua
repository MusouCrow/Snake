---@class UnityEngine.SkinQuality : System.Enum
---@field public Auto UnityEngine.SkinQuality @static
---@field public Bone1 UnityEngine.SkinQuality @static
---@field public Bone2 UnityEngine.SkinQuality @static
---@field public Bone4 UnityEngine.SkinQuality @static
---@field public value__ number
local m = {}

UnityEngine.SkinQuality = m
return m
