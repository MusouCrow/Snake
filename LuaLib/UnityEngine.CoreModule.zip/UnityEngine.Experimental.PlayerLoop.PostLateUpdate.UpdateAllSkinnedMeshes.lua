---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateAllSkinnedMeshes : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateAllSkinnedMeshes = m
return m
