---@class UnityEngine.ClassLibraryInitializer : System.Object
local m = {}

UnityEngine.ClassLibraryInitializer = m
return m
