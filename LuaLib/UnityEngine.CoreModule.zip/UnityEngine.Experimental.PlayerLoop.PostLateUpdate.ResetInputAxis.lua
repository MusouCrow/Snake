---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ResetInputAxis : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ResetInputAxis = m
return m
