---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.ScriptRunDelayedFixedFrameRate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.ScriptRunDelayedFixedFrameRate = m
return m
