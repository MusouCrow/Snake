---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ExecuteGameCenterCallbacks : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ExecuteGameCenterCallbacks = m
return m
