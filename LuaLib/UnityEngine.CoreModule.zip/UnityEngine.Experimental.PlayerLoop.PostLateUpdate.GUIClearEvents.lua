---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.GUIClearEvents : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.GUIClearEvents = m
return m
