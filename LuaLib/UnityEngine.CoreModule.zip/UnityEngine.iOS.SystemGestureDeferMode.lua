---@class UnityEngine.iOS.SystemGestureDeferMode : System.Enum
---@field public None UnityEngine.iOS.SystemGestureDeferMode @static
---@field public TopEdge UnityEngine.iOS.SystemGestureDeferMode @static
---@field public LeftEdge UnityEngine.iOS.SystemGestureDeferMode @static
---@field public BottomEdge UnityEngine.iOS.SystemGestureDeferMode @static
---@field public RightEdge UnityEngine.iOS.SystemGestureDeferMode @static
---@field public All UnityEngine.iOS.SystemGestureDeferMode @static
---@field public value__ number
local m = {}

UnityEngine.iOS.SystemGestureDeferMode = m
return m
