---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.PhysicsUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.PhysicsUpdate = m
return m
