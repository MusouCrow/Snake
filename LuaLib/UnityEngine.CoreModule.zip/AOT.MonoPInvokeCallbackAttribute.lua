---@class AOT.MonoPInvokeCallbackAttribute : System.Attribute
local m = {}

AOT.MonoPInvokeCallbackAttribute = m
return m
