---@class UnityEngine.HelpURLAttribute : System.Attribute
---@field public URL string
local m = {}

UnityEngine.HelpURLAttribute = m
return m
