---@class UnityEngine.RenderTextureReadWrite : System.Enum
---@field public Default UnityEngine.RenderTextureReadWrite @static
---@field public Linear UnityEngine.RenderTextureReadWrite @static
---@field public sRGB UnityEngine.RenderTextureReadWrite @static
---@field public value__ number
local m = {}

UnityEngine.RenderTextureReadWrite = m
return m
