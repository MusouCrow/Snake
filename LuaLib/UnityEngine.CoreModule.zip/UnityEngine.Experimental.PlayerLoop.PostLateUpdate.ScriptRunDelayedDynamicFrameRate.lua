---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ScriptRunDelayedDynamicFrameRate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ScriptRunDelayedDynamicFrameRate = m
return m
